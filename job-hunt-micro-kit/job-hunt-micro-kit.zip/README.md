# Auto Money Starter

This workspace contains a small, legal, ready-to-sell digital product package designed around a simple target: make at least USD 5 from a low-friction online sale.

## Offer

Product: **Job Hunt Micro Kit**

Price: **USD 5 minimum**

Buyer promise: In 20 minutes, turn a messy job search into a focused application plan with reusable prompts, a tracker, and outreach messages.

## Files

- `sales-page.html` - a single-page checkout landing page with a placeholder payment link.
- `product/job-hunt-micro-kit.md` - the actual digital product.
- `product/job-hunt-micro-kit.docx` - buyer-friendly document version.
- `product/job-tracker.csv` - lightweight job tracker buyers can import into Sheets/Excel/Notion.
- `operations/listing-copy.md` - copy for Gumroad, Ko-fi, Payhip, Lemon Squeezy, X, LinkedIn, Reddit, or private communities.
- `operations/fulfillment.md` - delivery workflow and buyer support snippets.

## Payment Link

The checkout link is set to:

```text
https://paypal.me/huangxu1428/5
```

PayPal.me does not provide automatic digital delivery, so the public sales page uses a lightweight honor-system flow: pay USD 5, then download the kit from the same page.

## Live Page

Published page:

```text
https://huangla.github.io/github-slideshow/job-hunt-micro-kit/index.html
```

Direct kit download:

```text
https://huangla.github.io/github-slideshow/job-hunt-micro-kit/job-hunt-micro-kit.zip
```
