# Fulfillment Workflow

## Recommended Setup

PayPal.me does not provide automatic digital delivery. The current public-page setup is an honor-system flow:

1. Buyer clicks the PayPal button.
2. Buyer pays USD 5.
3. Buyer downloads `job-hunt-micro-kit.zip` from the page.

For stricter delivery, use a digital product platform or payment tool that can deliver files automatically after purchase.

Possible setup:

1. Upload `product/job-hunt-micro-kit.docx`.
2. Upload `product/job-hunt-micro-kit.md` as a plain-text backup.
3. Upload `product/job-tracker.csv`.
4. Set price to USD 5.
5. Paste the listing copy from `operations/listing-copy.md`.
6. Replace the PayPal link if you later move to a hosted checkout.

## Delivery Email

Subject:
Your Job Hunt Micro Kit

Body:

```text
Thanks for buying the Job Hunt Micro Kit.

Your files are attached:

- job-hunt-micro-kit.docx
- job-hunt-micro-kit.md
- job-tracker.csv

Start with the 20-minute setup, then import the CSV into your spreadsheet tool of choice.

Good luck with the search.
```

## Support Reply

```text
Thanks for reaching out. If the download did not work, I can resend the files or issue a refund.

Can you send the email address used at checkout and a screenshot of the issue?
```

## Refund Reply

```text
Thanks for the note. Since this is a digital file, I normally refund only delivery or technical issues.

If the file did not download correctly, I can resend it right away. If that still does not work, I will refund the order.
```

## Update Reply

```text
Thanks for buying the kit. I updated the files with a cleaner tracker and more prompts.

Here is the latest version:
[download link]
```
