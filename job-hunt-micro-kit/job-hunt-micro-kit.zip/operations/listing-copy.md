# Listing Copy

## Product Title

Job Hunt Micro Kit: 20-Minute Application Reset

## Short Subtitle

A USD 5 digital kit with prompts, tracker, and outreach templates for a cleaner job search.

## Product Description

Feeling stuck in a messy job search? This small kit helps you reset in 20 minutes.

You get:

- A simple role scoring system so you stop applying randomly.
- AI prompts for role fit, resume bullets, cover notes, LinkedIn, and interview stories.
- Recruiter and hiring manager message templates.
- Follow-up templates for common situations.
- A CSV job tracker you can import into Google Sheets, Excel, Airtable, or Notion.

Best for:

- Job seekers applying to tech, product, operations, marketing, support, or remote roles.
- People who want structure without buying a course.
- People using AI tools but wanting prompts that stay honest and specific.

Not for:

- Guaranteed job placement.
- Fake resume writing.
- Replacing your own judgment.

Price: USD 5

## Checkout Button Text

Get the kit for USD 5

## Refund Policy

If the file is broken or not delivered, message me and I will fix it or refund the purchase. Because this is a digital download, refunds are not offered after successful delivery unless there is a technical issue.

## Gumroad / Payhip / Ko-fi Tags

job search, resume, career, templates, prompts, recruiter outreach, job tracker, AI prompts

## X / Twitter Post

I made a tiny USD 5 job search reset kit for people applying too randomly.

It includes:
- role fit scoring
- honest AI prompts
- recruiter messages
- follow-up templates
- a simple CSV tracker

Get it here:
https://paypal.me/huangxu1428/5

## LinkedIn Post

I made a small digital kit for job seekers who want a cleaner application process without buying a course.

The Job Hunt Micro Kit is a USD 5 download with:

- a role scoring framework
- resume and cover note prompts
- recruiter outreach templates
- follow-up messages
- a simple job tracker CSV

The goal is simple: fewer random applications, more focused ones.

Link:
https://paypal.me/huangxu1428/5

## Reddit / Community Post

Title:
I made a USD 5 job search reset kit with prompts, tracker, and outreach templates

Body:
I kept seeing people apply to dozens of jobs without a clear system, so I made a compact digital kit.

It includes a 20-minute setup, a role fit scoring system, AI prompts that avoid inventing experience, recruiter messages, follow-up templates, and a CSV tracker.

Price is USD 5. If you are in a tight spot, message me and I can share a free copy.

Link:
https://paypal.me/huangxu1428/5

## Direct Message To Potential Buyers

Hey [Name], I made a small USD 5 job search kit with prompts, a tracker, and recruiter message templates.

It is meant for people who are applying but feel scattered. No course, no fluff, just a 20-minute reset.

Link:
https://paypal.me/huangxu1428/5
