# Job Hunt Micro Kit

Price: USD 5

Version: 1.0

## What This Is

This is a 20-minute job search reset for people who feel scattered, stuck, or tired of applying randomly.

Use it to:

- Choose better roles to apply for.
- Turn one resume into targeted application angles.
- Write faster recruiter messages.
- Track applications without overbuilding a system.
- Follow up without sounding desperate.

## 20-Minute Setup

### Minute 0-3: Pick Your Target Lane

Fill this out before applying anywhere:

```text
Target role:
Target seniority:
Remote, hybrid, or onsite:
Preferred industries:
Must-have compensation:
Top 3 skills I want to use:
Top 3 things I want to avoid:
```

Now write one sentence:

```text
I am looking for [role] jobs where I can use [skill 1], [skill 2], and [skill 3] to help [type of company] achieve [business result].
```

Example:

```text
I am looking for frontend engineering roles where I can use React, TypeScript, and product thinking to help AI workflow companies ship polished user-facing tools.
```

### Minute 3-8: Score Roles Before Applying

Do not apply just because the title sounds close. Score each role from 0 to 2:

```text
Skills match:
Industry interest:
Location / work style:
Compensation likelihood:
Evidence I can show:
Total:
```

Apply only if the total is 7 or higher out of 10.

### Minute 8-14: Make A Tiny Resume Angle

For each good role, write 3 bullets that connect your experience to the job.

Prompt:

```text
Act as a practical resume editor. I will paste a job description and my background notes.
Return 3 resume bullets that are specific, honest, metric-oriented when possible, and aligned to the job.
Do not invent employers, dates, credentials, numbers, or technologies.

Job description:
[paste]

My background:
[paste]
```

Quality check:

- Does each bullet start with a strong verb?
- Does each bullet name the business or user outcome?
- Is every claim true?
- Can I explain the bullet in an interview?

### Minute 14-18: Send One Human Message

Use this when reaching a recruiter, founder, hiring manager, or team member.

```text
Hi [Name],

I saw the [Role] opening at [Company]. The part that stood out was [specific detail from the role/company].

My background is strongest in [skill/result], especially [short proof]. I applied through the usual channel, but wanted to send a quick note because the role looks close to the kind of work I do best.

Thanks,
[Your name]
```

Shorter version:

```text
Hi [Name], I applied for [Role] at [Company]. The focus on [specific detail] stood out to me. My strongest fit is [skill/result], with experience in [proof]. Thanks for taking a look.
```

### Minute 18-20: Track It

Use `job-tracker.csv` from this kit. Keep it boring. A tracker should make follow-up easier, not become a second job.

Minimum columns:

- Company
- Role
- URL
- Fit Score
- Contact
- Applied Date
- Follow-Up Date
- Status
- Next Action
- Notes

## Follow-Up Templates

### 5-7 Days After Applying

```text
Hi [Name],

Quick follow-up on my application for [Role]. I am still very interested, especially because of [specific reason].

The main experience I would bring is [relevant proof]. Happy to share anything else that would be useful.

Thanks,
[Your name]
```

### After A Recruiter Reply Goes Quiet

```text
Hi [Name],

Wanted to check in on [Role]. I know timing can shift, so no worries if the team is still reviewing.

I am still interested and available to talk if there is a fit.

Thanks,
[Your name]
```

### After Rejection

```text
Hi [Name],

Thanks for letting me know. I appreciate the update.

If another role opens that is closer to [specific skill/area], I would be glad to be considered.

Best,
[Your name]
```

## Prompts For Better Applications

### Role Fit Summary

```text
Compare this job description to my background. Return:
1. Strong matches
2. Weak matches
3. Missing keywords I should address honestly
4. A 0-10 fit score
5. A one-sentence application angle

Do not invent experience.

Job description:
[paste]

My background:
[paste]
```

### Cover Note

```text
Write a concise cover note under 160 words for this role.
Tone: direct, warm, specific, not exaggerated.
Use only the facts I provide.

Role:
[paste]

My background:
[paste]
```

### Interview Story Builder

```text
Turn this project into a STAR interview story.
Keep it under 90 seconds when spoken.
Do not invent numbers or outcomes.

Situation:
Task:
Action:
Result:
What I learned:
```

### LinkedIn About Section

```text
Rewrite my LinkedIn About section for [target role].
Make it concrete, readable, and recruiter-friendly.
Avoid hype words.
Keep it under 1,200 characters.

Current notes:
[paste]
```

## Weekly Operating System

Use this rhythm:

- Monday: Find 15 roles. Score them. Apply to the best 5.
- Tuesday: Send 5 human messages.
- Wednesday: Improve one resume bullet or portfolio proof.
- Thursday: Apply to 5 more high-fit roles.
- Friday: Follow up and clean the tracker.

The goal is not more applications. The goal is more high-fit applications with visible proof.

## License

Personal use only. Do not resell or redistribute this file as a standalone product.
